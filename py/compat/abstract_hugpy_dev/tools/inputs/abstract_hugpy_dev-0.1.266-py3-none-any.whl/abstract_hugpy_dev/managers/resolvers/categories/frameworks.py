from .imports import *
FRAMEWORK_RUNNERS: Dict[Tuple[str, str], Type[Runner]] = {
    ("transformers", "text-generation"):              DeepCoderChatRunner,
    ("gguf",         "text-generation"):              LlamaCppChatRunner,
    ("transformers", "image-text-to-text"):           VisionRunner,
    # GGUF vision (e.g. Qwen2.5-VL-*-GGUF): the gguf chat runner takes the same
    # ChatRequest and forwards image_url content in messages to llama.cpp's
    # chat-completion path — no separate VisionRunner shape.
    ("gguf",         "image-text-to-text"):           LlamaCppChatRunner,
    ("transformers", "automatic-speech-recognition"): WhisperRunner,
    # SPEECH OUT. Chatterbox is not a transformers pipeline — it is a checkpoint
    # dir plus its own loader — but the fleet's Runner protocol is about SERVING,
    # not about which library holds the weights, and the registry row's framework
    # is "transformers" because that is where its bytes live in the store. The
    # runner keeps the backend in a per-model env-PROFILE venv (its pins collide
    # with the agent's torch) and speaks the same request/result shapes as every
    # other row here. Before this row, EXTERNAL_TASK_RUNNERS could only DECLARE
    # where the runner lived; now the task also resolves.
    ("transformers", "text-to-speech"):               ChatterboxTtsRunner,
    ("transformers", "text-summarization"):                SummarizeRunner,
    ("transformers", "text2text-generation"):         SummarizeRunner,
    ("transformers", "feature-extraction"):           FeatureExtractionRunner,
    ("transformers", "sentence-similarity"):          FeatureExtractionRunner,
    ("transformers", "text-to-image"):                ImageGenRunner,
    # img2img sibling of text-to-image. INERT until a model advertises the task
    # (sd-turbo's advertisement flip is HELD — see models_config.py). Registering
    # the pair makes "image-to-image" a member of KNOWN_TASKS_REGISTRY and lets
    # validate_registry accept the flip when it goes live.
    ("transformers", "image-to-image"):               Img2ImgRunner,
    # ComfyUI engine (slice B): a comfy row's `filename` names a checkpoint in
    # the WORKER's own ComfyUI install; the runner drives its local :8188 with
    # vanilla-node templates and reuses the imagegen request/result, so
    # delegation + the b64 artifact seam work unchanged.
    ("comfy", "text-to-image"):                       ComfyRunner,
    ("comfy", "image-to-image"):                      ComfyRunner,
    # VIDEO (studio seat). The Wan/VACE registry rows are framework
    # "transformers" because that is where their bytes live in the store, but
    # they are SERVED by the studio spine: StudioVideoRunner lifts the request
    # into render_clip, which delegates to a studio GPU worker
    # (HUGPY_STUDIO_WORKER) when one resolves and the spec binds a real model.
    # Before these rows, text-to-video could only refuse with "no runner
    # registered" while the studio path rendered the same zoo one floor below.
    ("transformers", "text-to-video"):                StudioVideoRunner,
    ("transformers", "image-to-video"):               StudioVideoRunner,
    ("transformers", "keyword-extraction"):           KeywordRunner,
    # Vision-analysis family — ONE generic transformers-pipeline runner, a
    # subclass per task (see managers/vision_analysis). Adding the next HF
    # image task = a two-line subclass + a row here and in builders.
    ("transformers", "depth-estimation"):             DepthEstimationRunner,
    ("transformers", "object-detection"):             ObjectDetectionRunner,
    ("transformers", "image-classification"):         ImageClassificationRunner,
    ("transformers", "image-segmentation"):           ImageSegmentationRunner,
}

# Derived from FRAMEWORK_RUNNERS so it can't drift.
KNOWN_TASKS_REGISTRY: frozenset[str] = frozenset(task for _, task in FRAMEWORK_RUNNERS.keys())

