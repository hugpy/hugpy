"""Declarative eliminate-then-rank resolution — one framework, many pipelines.

A *pipeline* is an ordered tuple of named *stages*.  Each stage is one of:

  - ``eliminate`` — a keep-predicate ``fn(candidate, call) -> bool``.  Candidates
    that fail are dropped and recorded (``rejected_at`` = the stage name), so the
    decision log says *where* each loser fell out.
  - ``rank`` — a sort-key ``fn(candidate, call) -> comparable``.  Applied as a
    STABLE sort, so **the LAST ranker in the pipeline dominates** and earlier
    rankers only break ties beneath it.  This is how precedence is spelled out:
    put the weakest tiebreaker first and the strongest preference last.

The framework is stdlib-only and emits the existing oracle records
(:class:`~abstract_hugpy_dev.oracle.selection.CandidateVerdict` /
:class:`SelectionDecision`) as its envelope, so oracle callers are unchanged.
Two pipelines are expressed on it:

  * **name resolution** (``pipelines.name``) — fuzzy model-NAME → canonical key,
    used by ``assure_model_key`` (closest-string / blocked / fit / servable /
    adjusted-usage / starred).
  * **oracle selection** (``pipelines.oracle``) — the per-capability selector,
    a stage-for-stage mirror of ``selection.select`` steps 1-9, validated at
    parity before anything switches to it.

Nothing here reaches the network or a fleet; every fact a stage needs arrives
on the ``call`` object or the ``Candidate`` record, both injectable for tests.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Any, Callable, Iterable, Mapping, Optional

__all__ = [
    "Candidate",
    "Stage",
    "StageRegistry",
    "Unresolvable",
    "run_pipeline",
]


class Unresolvable(Exception):
    """Every candidate was eliminated (or there were none to begin with).

    Carries the ordered ``steps`` log and the ``rejected`` verdicts so the
    caller can render "here is what matched and why each fell out" — the same
    information ``selection.select`` returns as a ``gap`` decision.
    """

    def __init__(self, call: Any, *, steps: tuple[str, ...] = (),
                 rejected: tuple[Any, ...] = ()) -> None:
        super().__init__(f"unresolvable: {call!r}")
        self.call = call
        self.steps = steps
        self.rejected = rejected


@dataclass(frozen=True, slots=True)
class Candidate:
    """A frozen per-candidate record for the NAME-resolution pipeline.

    ``namespace`` is the collision-qualified key ("unsloth~Qwen3-Coder-Next-GGUF")
    and ``name`` its bare tail — carrying both dissolves the requested-alias vs
    served-key ambiguity at the record level.  The remaining fields are the
    facts the name-pipeline stages read; each is derived once, at construction,
    from the existing registry/serving seams (see ``pipelines.py``).
    """
    namespace: str
    name: str
    blocked: bool = False
    starred: bool = False
    servable: bool = False        # concrete artifact on disk / loadable
    serving: bool = False         # a live worker holds it right now
    fits: bool = True             # predesignated to fit VRAM (w/ or w/o evict)
    success_rank: int = 0         # 0 = most-recent success; large = stale
    adjusted_use: int = 0         # n_calls - tie_driven_picks
    evidence: Mapping[str, Any] = field(default_factory=dict)

    @property
    def model_id(self) -> str:
        """The key a resolved candidate becomes — the collision-qualified one."""
        return self.namespace


@dataclass(frozen=True, slots=True)
class Stage:
    name: str
    kind: str                     # "eliminate" | "rank"
    fn: Callable[[Any, Any], Any]

    def __post_init__(self) -> None:
        if self.kind not in ("eliminate", "rank"):
            raise ValueError(f"stage {self.name!r}: kind must be "
                             f"'eliminate' or 'rank', got {self.kind!r}")


class StageRegistry:
    """A named collection of stages plus the decorator that fills it.

    Each pipeline owns its own registry so stage names never collide across
    pipelines and the PIPELINE tuple reads as a local table of precedence.
    """

    def __init__(self) -> None:
        self._stages: dict[str, Stage] = {}

    def stage(self, name: str, kind: str) -> Callable[[Callable], Callable]:
        def _register(fn: Callable[[Any, Any], Any]) -> Callable:
            self._stages[name] = Stage(name, kind, fn)
            return fn
        return _register

    def get(self, name: str) -> Stage:
        try:
            return self._stages[name]
        except KeyError:
            raise KeyError(f"no stage registered under {name!r}; "
                           f"known: {sorted(self._stages)}") from None

    def __contains__(self, name: str) -> bool:
        return name in self._stages


def run_pipeline(
    call: Any,
    candidates: Iterable[Any],
    pipeline: tuple[str, ...],
    registry: StageRegistry,
    *,
    make_reject: Optional[Callable[[Any, str], Any]] = None,
) -> tuple[list[Any], list[Any], list[str]]:
    """Apply ``pipeline`` to ``candidates`` and return (kept, rejected, steps).

    ``kept`` is best-first (head is the winner).  ``rejected`` holds one record
    per eliminated candidate — built by ``make_reject(candidate, stage_name)``
    when given, else the raw candidate.  ``steps`` is the ordered human log.

    Ranking is a *stable* sort re-applied per ranker in pipeline order, so the
    final order reflects "last ranker dominates, earlier rankers break ties".
    Eliminate stages that empty the queue stop the pipeline early (there is
    nothing left to rank) and the emptying stage is named in the log.
    """
    queue: list[Any] = list(candidates)
    rejected: list[Any] = []
    steps: list[str] = []

    for name in pipeline:
        st = registry.get(name)
        if st.kind == "eliminate":
            kept: list[Any] = []
            dropped = 0
            for c in queue:
                if st.fn(c, call):
                    kept.append(c)
                else:
                    dropped += 1
                    rejected.append(make_reject(c, name) if make_reject else c)
            queue = kept
            steps.append(f"{name}: {len(queue)} kept"
                         + (f", {dropped} eliminated" if dropped else ""))
            if not queue:
                steps.append(f"-> unresolvable at {name}: no candidate left")
                return [], rejected, steps
        else:  # rank — stable sort, last ranker wins
            queue.sort(key=lambda c: st.fn(c, call))
            steps.append(f"{name}: ranked {[getattr(c, 'model_id', c) for c in queue]}")

    return queue, rejected, steps
