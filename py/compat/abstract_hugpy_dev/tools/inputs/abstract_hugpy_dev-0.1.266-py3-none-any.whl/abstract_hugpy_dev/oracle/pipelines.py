"""The two concrete pipelines built on :mod:`oracle.pipeline`.

* :data:`NAME_PIPELINE` / :data:`name_registry` — resolve a fuzzy model NAME to
  a canonical registry key.  This is the pipeline ``assure_model_key`` calls
  once its exact/slug/hub/folder/bare-tail cascade has failed.  Precedence is
  spelled out by ordering (last ranker dominates):

      closest-string   (weakest rank: token/edit distance — pure tiebreaker)
      exact            (eliminate: alloc.exact -> keep only the requested ns)
      blocked          (eliminate: operator-blocked / unclassified / adapter)
      fit              (eliminate: predesignated to fit VRAM)
      servable         (eliminate: has a concrete loadable artifact)
      adjusted-usage   (rank: n_calls - tie_driven_picks)
      serving          (rank: prefer a model a worker holds right now)
      starred          (strongest rank: an operator-starred model wins)

* :data:`ORACLE_PIPELINE` / :data:`oracle_registry` — a stage-for-stage mirror
  of :func:`selection.select` steps 1-9, used only behind the parity gate.

The stage bodies delegate to existing seams; every seam read is fail-open so a
metrics DB round-trip or a missing worker store never raises into resolution.
"""
from __future__ import annotations

from typing import Any

from .pipeline import Candidate, StageRegistry, run_pipeline

# --------------------------------------------------------------------------- #
# name-resolution pipeline (Pipeline A)
# --------------------------------------------------------------------------- #

name_registry = StageRegistry()


def _tokens(value: str) -> list[str]:
    """Lower-case word tokens, folding ``_`` ``-`` ``~`` ``/`` and whitespace."""
    import re
    return [t for t in re.split(r"[\s_~/-]+", str(value).lower()) if t]


def _distance(name: str, want: str) -> int:
    """How far a candidate name is from the request: extra tokens it carries
    beyond what was asked (0 = exact token set).  A cheap, stable proxy for
    "closest" that does NOT prefer merely-shorter names — a candidate with the
    requested tokens plus one extra ranks ahead of one with three extra."""
    want_t = set(_tokens(want))
    cand_t = _tokens(name)
    return sum(1 for t in cand_t if t not in want_t)


@name_registry.stage("closest-string", "rank")
def _closest(c: Candidate, call: "NameCall") -> int:
    return _distance(c.name, call.requested)


@name_registry.stage("exact", "eliminate")
def _exact(c: Candidate, call: "NameCall") -> bool:
    # alloc.exact: keep only candidates matching the requested namespace/name.
    if not call.exact:
        return True
    req = call.requested.strip().lower()
    return c.namespace.lower() == req or c.name.lower() == req


@name_registry.stage("blocked", "eliminate")
def _not_blocked(c: Candidate, call: "NameCall") -> bool:
    return not c.blocked


@name_registry.stage("fit", "eliminate")
def _fits(c: Candidate, call: "NameCall") -> bool:
    return c.fits


@name_registry.stage("servable", "eliminate")
def _servable(c: Candidate, call: "NameCall") -> bool:
    # Only enforced when at least one candidate is servable — otherwise a
    # cold/never-installed registry would eliminate everything.  The registry
    # facts still let a truly-unservable lone candidate through to a later
    # error rather than pretending it is loadable.
    return c.servable if call.any_servable else True


@name_registry.stage("adjusted-usage", "rank")
def _usage(c: Candidate, call: "NameCall") -> int:
    return -c.adjusted_use          # higher use sorts first


@name_registry.stage("serving", "rank")
def _serving(c: Candidate, call: "NameCall") -> bool:
    return not c.serving            # False(0) sorts first -> loaded wins


@name_registry.stage("starred", "rank")
def _starred(c: Candidate, call: "NameCall") -> bool:
    return not c.starred            # starred sorts first (dominant, last)


NAME_PIPELINE: tuple[str, ...] = (
    "closest-string",   # weakest ranker (pure tiebreaker)
    "exact",            # eliminate: alloc.exact pin
    "blocked",          # eliminate
    "fit",              # eliminate
    "servable",         # eliminate
    "adjusted-usage",   # rank
    "serving",          # rank
    "starred",          # strongest ranker (last wins)
)


class NameCall:
    """The request side of a name resolution."""

    __slots__ = ("requested", "exact", "any_servable")

    def __init__(self, requested: str, *, exact: bool = False,
                 any_servable: bool = False) -> None:
        self.requested = str(requested)
        self.exact = bool(exact)
        self.any_servable = bool(any_servable)


def resolve_name(requested: str, candidates: list[Candidate], *,
                 exact: bool = False) -> tuple[list[Candidate], list[str]]:
    """Run the name pipeline; return (ranked candidates best-first, steps log).

    Empty ranked list means "eliminated to nothing" (caller fails with the
    candidate list).  A tie the rankers cannot break leaves >1 at distance 0 —
    the caller treats a non-unique head as ambiguous.
    """
    call = NameCall(requested, exact=exact,
                    any_servable=any(c.servable for c in candidates))
    kept, _rej, steps = run_pipeline(call, candidates, NAME_PIPELINE, name_registry)
    return kept, steps
